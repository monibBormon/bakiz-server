const app = require('./app');

const PORT = process.env.PORT || 'https://bakiz-server.monibbormon.com';

app.listen(PORT,function(){
    console.log(`Server running port ${PORT}`);
})